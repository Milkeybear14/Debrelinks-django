from django.contrib import admin
from .models import what_we_do,why_choose_us,clients_response,year
# Register your models here.
admin.site.register(what_we_do)
admin.site.register(why_choose_us)
admin.site.register(clients_response)
admin.site.register(year)