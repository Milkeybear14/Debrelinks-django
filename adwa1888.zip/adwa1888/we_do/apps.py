from django.apps import AppConfig


class WeDoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'we_do'
